<?php echo e($slot); ?>

<?php /**PATH /var/www/vhosts/128/310884/webspace/httpdocs/pointrush/pointrush/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>