

<?php $__env->startSection('content'); ?>
<div class="container">

<h1>Pointrush</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/128/310884/webspace/httpdocs/pointrush/pointrush/resources/views/homepage.blade.php ENDPATH**/ ?>