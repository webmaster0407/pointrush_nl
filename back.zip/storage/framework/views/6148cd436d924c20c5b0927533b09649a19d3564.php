

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <?php if(Auth::user()->roles==0): ?>
        <a href="/admin/adduser" class="btn btn-success"><?php echo e(__('basic.add_user')); ?></a>
        <?php endif; ?>
        <a href="/admin/addtrack" class="btn btn-primary ml-2"><?php echo e(__('basic.add_track')); ?></a>
    </div>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row justify-content-center pt-3">
        <div class="col-md-12">
            <div class="card<?php echo e($u->id==1?' border-primary ':''); ?>">

                <div class="card-header d-flex justify-content-between"><?php echo e($u->email); ?>

                    <?php if(Auth::user()->roles==0 && $u->id!=1): ?>
                    <button class="btn btn-sm btn-danger ml-2 remove-user" data-uid="<?php echo e($u->id); ?>" data-email="<?php echo e($u->email); ?>"><?php echo e(__('basic.remove')); ?></button>
                    <?php endif; ?>
                </div>

                <div class="card-body">


                    <ul class="list-group">
                        


                        <?php if(sizeof($u->tracks)): ?>
                        <?php $__currentLoopData = $u->tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="list-group-item list-group-item-action d-flex justify-content-between tracktitle" id="track-<?php echo e($track->id); ?>">
                            <div>
                                
                                    #<?php echo e($track->id); ?> <?php echo e($track->title); ?>

                                     </div>
                            <div>
                                <a href="/admin/edittrack/<?php echo e($track->id); ?>" class="btn btn-default edit-tracktitle btn-sm"><i class="fas fa-edit"></i></a>
                              
                                <a href="/admin/track/<?php echo e($track->id); ?>" class="btn btn-sm btn-primary edit-track"><?php echo e(__('basic.edit')); ?></a>
                                <button class="btn btn-sm btn-warning ml-2 remove-track" data-tid="<?php echo e($track->id); ?>" data-title="<?php echo e($track->title); ?>"><?php echo e(__('basic.remove')); ?></button>
                            </div>
                        </li>
                        <li class="list-group-item list-group-item-action disabled trackcontent" id="trackc-<?php echo e($track->id); ?>">
                            <p><?php echo e(__('basic.loading')); ?></p>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <li class="list-group-item list-group-item-action text-center disabled"><?php echo e(__('basic.nothing_to_show')); ?></li>
                        <?php endif; ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/128/310884/webspace/httpdocs/pointrush/pointrush/resources/views/admin.blade.php ENDPATH**/ ?>