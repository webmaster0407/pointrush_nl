<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /var/www/vhosts/128/310884/webspace/httpdocs/pointrush/pointrush/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>